pub mod rmw {
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__msg__ProgramState() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__msg__ProgramState__init(msg: *mut ProgramState) -> bool;
    fn ur_dashboard_msgs__msg__ProgramState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ProgramState>, size: usize) -> bool;
    fn ur_dashboard_msgs__msg__ProgramState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ProgramState>);
    fn ur_dashboard_msgs__msg__ProgramState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ProgramState>, out_seq: *mut rosidl_runtime_rs::Sequence<ProgramState>) -> bool;
}

// Corresponds to ur_dashboard_msgs__msg__ProgramState
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ProgramState {
    pub state: rosidl_runtime_rs::String,
}

impl ProgramState {
    pub const STOPPED: &'static str = "STOPPED";
    pub const PLAYING: &'static str = "PLAYING";
    pub const PAUSED: &'static str = "PAUSED";
}


impl Default for ProgramState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__msg__ProgramState__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__msg__ProgramState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ProgramState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__ProgramState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__ProgramState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__ProgramState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ProgramState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ProgramState where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/msg/ProgramState";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__msg__ProgramState() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__msg__RobotMode() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__msg__RobotMode__init(msg: *mut RobotMode) -> bool;
    fn ur_dashboard_msgs__msg__RobotMode__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RobotMode>, size: usize) -> bool;
    fn ur_dashboard_msgs__msg__RobotMode__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RobotMode>);
    fn ur_dashboard_msgs__msg__RobotMode__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RobotMode>, out_seq: *mut rosidl_runtime_rs::Sequence<RobotMode>) -> bool;
}

// Corresponds to ur_dashboard_msgs__msg__RobotMode
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobotMode {
    pub mode: i8,
}

impl RobotMode {
    pub const NO_CONTROLLER: i8 = -1;
    pub const DISCONNECTED: i8 = 0;
    pub const CONFIRM_SAFETY: i8 = 1;
    pub const BOOTING: i8 = 2;
    pub const POWER_OFF: i8 = 3;
    pub const POWER_ON: i8 = 4;
    pub const IDLE: i8 = 5;
    pub const BACKDRIVE: i8 = 6;
    pub const RUNNING: i8 = 7;
    pub const UPDATING_FIRMWARE: i8 = 8;
}


impl Default for RobotMode {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__msg__RobotMode__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__msg__RobotMode__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RobotMode {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__RobotMode__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__RobotMode__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__RobotMode__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RobotMode {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RobotMode where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/msg/RobotMode";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__msg__RobotMode() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__msg__SafetyMode() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__msg__SafetyMode__init(msg: *mut SafetyMode) -> bool;
    fn ur_dashboard_msgs__msg__SafetyMode__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<SafetyMode>, size: usize) -> bool;
    fn ur_dashboard_msgs__msg__SafetyMode__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<SafetyMode>);
    fn ur_dashboard_msgs__msg__SafetyMode__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<SafetyMode>, out_seq: *mut rosidl_runtime_rs::Sequence<SafetyMode>) -> bool;
}

// Corresponds to ur_dashboard_msgs__msg__SafetyMode
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SafetyMode {
    pub mode: u8,
}

impl SafetyMode {
    pub const NORMAL: u8 = 1;
    pub const REDUCED: u8 = 2;
    pub const PROTECTIVE_STOP: u8 = 3;
    pub const RECOVERY: u8 = 4;
    pub const SAFEGUARD_STOP: u8 = 5;
    pub const SYSTEM_EMERGENCY_STOP: u8 = 6;
    pub const ROBOT_EMERGENCY_STOP: u8 = 7;
    pub const VIOLATION: u8 = 8;
    pub const FAULT: u8 = 9;
    pub const VALIDATE_JOINT_ID: u8 = 10;
    pub const UNDEFINED_SAFETY_MODE: u8 = 11;
    pub const AUTOMATIC_MODE_SAFEGUARD_STOP: u8 = 12;
    pub const SYSTEM_THREE_POSITION_ENABLING_STOP: u8 = 13;
}


impl Default for SafetyMode {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__msg__SafetyMode__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__msg__SafetyMode__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for SafetyMode {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__SafetyMode__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__SafetyMode__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__msg__SafetyMode__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for SafetyMode {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for SafetyMode where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/msg/SafetyMode";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__msg__SafetyMode() }
  }
}


}  // mod rmw


#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ProgramState {
    pub state: std::string::String,
}

impl ProgramState {
    pub const STOPPED: &'static str = "STOPPED";
    pub const PLAYING: &'static str = "PLAYING";
    pub const PAUSED: &'static str = "PAUSED";
}


impl Default for ProgramState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::msg::rmw::ProgramState::default())
  }
}

impl rosidl_runtime_rs::Message for ProgramState {
  type RmwMsg = crate::msg::rmw::ProgramState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: msg.state.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: msg.state.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      state: msg.state.to_string(),
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobotMode {
    pub mode: i8,
}

impl RobotMode {
    pub const NO_CONTROLLER: i8 = -1;
    pub const DISCONNECTED: i8 = 0;
    pub const CONFIRM_SAFETY: i8 = 1;
    pub const BOOTING: i8 = 2;
    pub const POWER_OFF: i8 = 3;
    pub const POWER_ON: i8 = 4;
    pub const IDLE: i8 = 5;
    pub const BACKDRIVE: i8 = 6;
    pub const RUNNING: i8 = 7;
    pub const UPDATING_FIRMWARE: i8 = 8;
}


impl Default for RobotMode {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::msg::rmw::RobotMode::default())
  }
}

impl rosidl_runtime_rs::Message for RobotMode {
  type RmwMsg = crate::msg::rmw::RobotMode;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mode: msg.mode,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      mode: msg.mode,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      mode: msg.mode,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct SafetyMode {
    pub mode: u8,
}

impl SafetyMode {
    pub const NORMAL: u8 = 1;
    pub const REDUCED: u8 = 2;
    pub const PROTECTIVE_STOP: u8 = 3;
    pub const RECOVERY: u8 = 4;
    pub const SAFEGUARD_STOP: u8 = 5;
    pub const SYSTEM_EMERGENCY_STOP: u8 = 6;
    pub const ROBOT_EMERGENCY_STOP: u8 = 7;
    pub const VIOLATION: u8 = 8;
    pub const FAULT: u8 = 9;
    pub const VALIDATE_JOINT_ID: u8 = 10;
    pub const UNDEFINED_SAFETY_MODE: u8 = 11;
    pub const AUTOMATIC_MODE_SAFEGUARD_STOP: u8 = 12;
    pub const SYSTEM_THREE_POSITION_ENABLING_STOP: u8 = 13;
}


impl Default for SafetyMode {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::msg::rmw::SafetyMode::default())
  }
}

impl rosidl_runtime_rs::Message for SafetyMode {
  type RmwMsg = crate::msg::rmw::SafetyMode;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mode: msg.mode,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      mode: msg.mode,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      mode: msg.mode,
    }
  }
}


