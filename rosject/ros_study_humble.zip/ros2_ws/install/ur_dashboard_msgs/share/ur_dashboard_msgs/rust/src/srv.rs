

#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddToLog_Request {
    pub message: std::string::String,
}



impl Default for AddToLog_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::AddToLog_Request::default())
  }
}

impl rosidl_runtime_rs::Message for AddToLog_Request {
  type RmwMsg = crate::srv::rmw::AddToLog_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      message: msg.message.to_string(),
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddToLog_Response {
    pub answer: std::string::String,
    pub success: bool,
}



impl Default for AddToLog_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::AddToLog_Response::default())
  }
}

impl rosidl_runtime_rs::Message for AddToLog_Response {
  type RmwMsg = crate::srv::rmw::AddToLog_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetLoadedProgram_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetLoadedProgram_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetLoadedProgram_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetLoadedProgram_Request {
  type RmwMsg = crate::srv::rmw::GetLoadedProgram_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetLoadedProgram_Response {
    pub answer: std::string::String,
    pub program_name: std::string::String,
    pub success: bool,
}



impl Default for GetLoadedProgram_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetLoadedProgram_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetLoadedProgram_Response {
  type RmwMsg = crate::srv::rmw::GetLoadedProgram_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        program_name: msg.program_name.as_str().into(),
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        program_name: msg.program_name.as_str().into(),
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
      program_name: msg.program_name.to_string(),
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetProgramState_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetProgramState_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetProgramState_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetProgramState_Request {
  type RmwMsg = crate::srv::rmw::GetProgramState_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetProgramState_Response {
    pub state: crate::msg::ProgramState,
    pub program_name: std::string::String,
    pub answer: std::string::String,
    pub success: bool,
}



impl Default for GetProgramState_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetProgramState_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetProgramState_Response {
  type RmwMsg = crate::srv::rmw::GetProgramState_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: crate::msg::ProgramState::into_rmw_message(std::borrow::Cow::Owned(msg.state)).into_owned(),
        program_name: msg.program_name.as_str().into(),
        answer: msg.answer.as_str().into(),
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: crate::msg::ProgramState::into_rmw_message(std::borrow::Cow::Borrowed(&msg.state)).into_owned(),
        program_name: msg.program_name.as_str().into(),
        answer: msg.answer.as_str().into(),
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      state: crate::msg::ProgramState::from_rmw_message(msg.state),
      program_name: msg.program_name.to_string(),
      answer: msg.answer.to_string(),
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetRobotMode_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetRobotMode_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetRobotMode_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetRobotMode_Request {
  type RmwMsg = crate::srv::rmw::GetRobotMode_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetRobotMode_Response {
    pub robot_mode: crate::msg::RobotMode,
    pub answer: std::string::String,
    pub success: bool,
}



impl Default for GetRobotMode_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetRobotMode_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetRobotMode_Response {
  type RmwMsg = crate::srv::rmw::GetRobotMode_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        robot_mode: crate::msg::RobotMode::into_rmw_message(std::borrow::Cow::Owned(msg.robot_mode)).into_owned(),
        answer: msg.answer.as_str().into(),
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        robot_mode: crate::msg::RobotMode::into_rmw_message(std::borrow::Cow::Borrowed(&msg.robot_mode)).into_owned(),
        answer: msg.answer.as_str().into(),
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      robot_mode: crate::msg::RobotMode::from_rmw_message(msg.robot_mode),
      answer: msg.answer.to_string(),
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetSafetyMode_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetSafetyMode_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetSafetyMode_Request::default())
  }
}

impl rosidl_runtime_rs::Message for GetSafetyMode_Request {
  type RmwMsg = crate::srv::rmw::GetSafetyMode_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetSafetyMode_Response {
    pub safety_mode: crate::msg::SafetyMode,
    pub answer: std::string::String,
    pub success: bool,
}



impl Default for GetSafetyMode_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::GetSafetyMode_Response::default())
  }
}

impl rosidl_runtime_rs::Message for GetSafetyMode_Response {
  type RmwMsg = crate::srv::rmw::GetSafetyMode_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        safety_mode: crate::msg::SafetyMode::into_rmw_message(std::borrow::Cow::Owned(msg.safety_mode)).into_owned(),
        answer: msg.answer.as_str().into(),
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        safety_mode: crate::msg::SafetyMode::into_rmw_message(std::borrow::Cow::Borrowed(&msg.safety_mode)).into_owned(),
        answer: msg.answer.as_str().into(),
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      safety_mode: crate::msg::SafetyMode::from_rmw_message(msg.safety_mode),
      answer: msg.answer.to_string(),
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramRunning_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for IsProgramRunning_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::IsProgramRunning_Request::default())
  }
}

impl rosidl_runtime_rs::Message for IsProgramRunning_Request {
  type RmwMsg = crate::srv::rmw::IsProgramRunning_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramRunning_Response {
    pub answer: std::string::String,
    pub program_running: bool,
    pub success: bool,
}



impl Default for IsProgramRunning_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::IsProgramRunning_Response::default())
  }
}

impl rosidl_runtime_rs::Message for IsProgramRunning_Response {
  type RmwMsg = crate::srv::rmw::IsProgramRunning_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        program_running: msg.program_running,
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
      program_running: msg.program_running,
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
      program_running: msg.program_running,
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramSaved_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for IsProgramSaved_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::IsProgramSaved_Request::default())
  }
}

impl rosidl_runtime_rs::Message for IsProgramSaved_Request {
  type RmwMsg = crate::srv::rmw::IsProgramSaved_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramSaved_Response {
    pub answer: std::string::String,
    pub program_name: std::string::String,
    pub program_saved: bool,
    pub success: bool,
}



impl Default for IsProgramSaved_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::IsProgramSaved_Response::default())
  }
}

impl rosidl_runtime_rs::Message for IsProgramSaved_Response {
  type RmwMsg = crate::srv::rmw::IsProgramSaved_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        program_name: msg.program_name.as_str().into(),
        program_saved: msg.program_saved,
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        program_name: msg.program_name.as_str().into(),
      program_saved: msg.program_saved,
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
      program_name: msg.program_name.to_string(),
      program_saved: msg.program_saved,
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Load_Request {
    pub filename: std::string::String,
}



impl Default for Load_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::Load_Request::default())
  }
}

impl rosidl_runtime_rs::Message for Load_Request {
  type RmwMsg = crate::srv::rmw::Load_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        filename: msg.filename.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        filename: msg.filename.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      filename: msg.filename.to_string(),
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Load_Response {
    pub answer: std::string::String,
    pub success: bool,
}



impl Default for Load_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::Load_Response::default())
  }
}

impl rosidl_runtime_rs::Message for Load_Response {
  type RmwMsg = crate::srv::rmw::Load_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Popup_Request {
    pub message: std::string::String,
}



impl Default for Popup_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::Popup_Request::default())
  }
}

impl rosidl_runtime_rs::Message for Popup_Request {
  type RmwMsg = crate::srv::rmw::Popup_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        message: msg.message.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        message: msg.message.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      message: msg.message.to_string(),
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Popup_Response {
    pub answer: std::string::String,
    pub success: bool,
}



impl Default for Popup_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::Popup_Response::default())
  }
}

impl rosidl_runtime_rs::Message for Popup_Response {
  type RmwMsg = crate::srv::rmw::Popup_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
      success: msg.success,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RawRequest_Request {
    pub query: std::string::String,
}



impl Default for RawRequest_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::RawRequest_Request::default())
  }
}

impl rosidl_runtime_rs::Message for RawRequest_Request {
  type RmwMsg = crate::srv::rmw::RawRequest_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        query: msg.query.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        query: msg.query.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      query: msg.query.to_string(),
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RawRequest_Response {
    pub answer: std::string::String,
}



impl Default for RawRequest_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::RawRequest_Response::default())
  }
}

impl rosidl_runtime_rs::Message for RawRequest_Response {
  type RmwMsg = crate::srv::rmw::RawRequest_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsInRemoteControl_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for IsInRemoteControl_Request {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::IsInRemoteControl_Request::default())
  }
}

impl rosidl_runtime_rs::Message for IsInRemoteControl_Request {
  type RmwMsg = crate::srv::rmw::IsInRemoteControl_Request;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      structure_needs_at_least_one_member: msg.structure_needs_at_least_one_member,
    }
  }
}


#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsInRemoteControl_Response {
    pub answer: std::string::String,
    pub remote_control: bool,
    pub success: bool,
}



impl Default for IsInRemoteControl_Response {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(crate::srv::rmw::IsInRemoteControl_Response::default())
  }
}

impl rosidl_runtime_rs::Message for IsInRemoteControl_Response {
  type RmwMsg = crate::srv::rmw::IsInRemoteControl_Response;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
        remote_control: msg.remote_control,
        success: msg.success,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        answer: msg.answer.as_str().into(),
      remote_control: msg.remote_control,
      success: msg.success,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      answer: msg.answer.to_string(),
      remote_control: msg.remote_control,
      success: msg.success,
    }
  }
}






#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__AddToLog() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__AddToLog
pub struct AddToLog;

impl rosidl_runtime_rs::Service for AddToLog {
  type Request = crate::srv::AddToLog_Request;
  type Response = crate::srv::AddToLog_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__AddToLog() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__GetLoadedProgram
pub struct GetLoadedProgram;

impl rosidl_runtime_rs::Service for GetLoadedProgram {
  type Request = crate::srv::GetLoadedProgram_Request;
  type Response = crate::srv::GetLoadedProgram_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetProgramState() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__GetProgramState
pub struct GetProgramState;

impl rosidl_runtime_rs::Service for GetProgramState {
  type Request = crate::srv::GetProgramState_Request;
  type Response = crate::srv::GetProgramState_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetProgramState() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__GetRobotMode
pub struct GetRobotMode;

impl rosidl_runtime_rs::Service for GetRobotMode {
  type Request = crate::srv::GetRobotMode_Request;
  type Response = crate::srv::GetRobotMode_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__GetSafetyMode
pub struct GetSafetyMode;

impl rosidl_runtime_rs::Service for GetSafetyMode {
  type Request = crate::srv::GetSafetyMode_Request;
  type Response = crate::srv::GetSafetyMode_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__IsProgramRunning
pub struct IsProgramRunning;

impl rosidl_runtime_rs::Service for IsProgramRunning {
  type Request = crate::srv::IsProgramRunning_Request;
  type Response = crate::srv::IsProgramRunning_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__IsProgramSaved
pub struct IsProgramSaved;

impl rosidl_runtime_rs::Service for IsProgramSaved {
  type Request = crate::srv::IsProgramSaved_Request;
  type Response = crate::srv::IsProgramSaved_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Load() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__Load
pub struct Load;

impl rosidl_runtime_rs::Service for Load {
  type Request = crate::srv::Load_Request;
  type Response = crate::srv::Load_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Load() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Popup() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__Popup
pub struct Popup;

impl rosidl_runtime_rs::Service for Popup {
  type Request = crate::srv::Popup_Request;
  type Response = crate::srv::Popup_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Popup() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__RawRequest() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__RawRequest
pub struct RawRequest;

impl rosidl_runtime_rs::Service for RawRequest {
  type Request = crate::srv::RawRequest_Request;
  type Response = crate::srv::RawRequest_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__RawRequest() }
  }
}




#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl() -> *const std::os::raw::c_void;
}

// Corresponds to ur_dashboard_msgs__srv__IsInRemoteControl
pub struct IsInRemoteControl;

impl rosidl_runtime_rs::Service for IsInRemoteControl {
  type Request = crate::srv::IsInRemoteControl_Request;
  type Response = crate::srv::IsInRemoteControl_Response;

  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl() }
  }
}



pub mod rmw {
#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};

#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__AddToLog_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__AddToLog_Request__init(msg: *mut AddToLog_Request) -> bool;
    fn ur_dashboard_msgs__srv__AddToLog_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<AddToLog_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__AddToLog_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<AddToLog_Request>);
    fn ur_dashboard_msgs__srv__AddToLog_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<AddToLog_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<AddToLog_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__AddToLog_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddToLog_Request {
    pub message: rosidl_runtime_rs::String,
}



impl Default for AddToLog_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__AddToLog_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__AddToLog_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for AddToLog_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__AddToLog_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__AddToLog_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__AddToLog_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for AddToLog_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for AddToLog_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/AddToLog_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__AddToLog_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__AddToLog_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__AddToLog_Response__init(msg: *mut AddToLog_Response) -> bool;
    fn ur_dashboard_msgs__srv__AddToLog_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<AddToLog_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__AddToLog_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<AddToLog_Response>);
    fn ur_dashboard_msgs__srv__AddToLog_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<AddToLog_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<AddToLog_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__AddToLog_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct AddToLog_Response {
    pub answer: rosidl_runtime_rs::String,
    pub success: bool,
}



impl Default for AddToLog_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__AddToLog_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__AddToLog_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for AddToLog_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__AddToLog_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__AddToLog_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__AddToLog_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for AddToLog_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for AddToLog_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/AddToLog_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__AddToLog_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Request__init(msg: *mut GetLoadedProgram_Request) -> bool;
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetLoadedProgram_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetLoadedProgram_Request>);
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetLoadedProgram_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetLoadedProgram_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetLoadedProgram_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetLoadedProgram_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetLoadedProgram_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetLoadedProgram_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetLoadedProgram_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetLoadedProgram_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetLoadedProgram_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetLoadedProgram_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetLoadedProgram_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetLoadedProgram_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetLoadedProgram_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetLoadedProgram_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Response__init(msg: *mut GetLoadedProgram_Response) -> bool;
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetLoadedProgram_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetLoadedProgram_Response>);
    fn ur_dashboard_msgs__srv__GetLoadedProgram_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetLoadedProgram_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetLoadedProgram_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetLoadedProgram_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetLoadedProgram_Response {
    pub answer: rosidl_runtime_rs::String,
    pub program_name: rosidl_runtime_rs::String,
    pub success: bool,
}



impl Default for GetLoadedProgram_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetLoadedProgram_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetLoadedProgram_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetLoadedProgram_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetLoadedProgram_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetLoadedProgram_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetLoadedProgram_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetLoadedProgram_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetLoadedProgram_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetLoadedProgram_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetProgramState_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetProgramState_Request__init(msg: *mut GetProgramState_Request) -> bool;
    fn ur_dashboard_msgs__srv__GetProgramState_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetProgramState_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetProgramState_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetProgramState_Request>);
    fn ur_dashboard_msgs__srv__GetProgramState_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetProgramState_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetProgramState_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetProgramState_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetProgramState_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetProgramState_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetProgramState_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetProgramState_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetProgramState_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetProgramState_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetProgramState_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetProgramState_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetProgramState_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetProgramState_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetProgramState_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetProgramState_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetProgramState_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetProgramState_Response__init(msg: *mut GetProgramState_Response) -> bool;
    fn ur_dashboard_msgs__srv__GetProgramState_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetProgramState_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetProgramState_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetProgramState_Response>);
    fn ur_dashboard_msgs__srv__GetProgramState_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetProgramState_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetProgramState_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetProgramState_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetProgramState_Response {
    pub state: crate::msg::rmw::ProgramState,
    pub program_name: rosidl_runtime_rs::String,
    pub answer: rosidl_runtime_rs::String,
    pub success: bool,
}



impl Default for GetProgramState_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetProgramState_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetProgramState_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetProgramState_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetProgramState_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetProgramState_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetProgramState_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetProgramState_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetProgramState_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetProgramState_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetProgramState_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetRobotMode_Request__init(msg: *mut GetRobotMode_Request) -> bool;
    fn ur_dashboard_msgs__srv__GetRobotMode_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetRobotMode_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetRobotMode_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetRobotMode_Request>);
    fn ur_dashboard_msgs__srv__GetRobotMode_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetRobotMode_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetRobotMode_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetRobotMode_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetRobotMode_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetRobotMode_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetRobotMode_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetRobotMode_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetRobotMode_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetRobotMode_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetRobotMode_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetRobotMode_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetRobotMode_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetRobotMode_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetRobotMode_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetRobotMode_Response__init(msg: *mut GetRobotMode_Response) -> bool;
    fn ur_dashboard_msgs__srv__GetRobotMode_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetRobotMode_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetRobotMode_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetRobotMode_Response>);
    fn ur_dashboard_msgs__srv__GetRobotMode_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetRobotMode_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetRobotMode_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetRobotMode_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetRobotMode_Response {
    pub robot_mode: crate::msg::rmw::RobotMode,
    pub answer: rosidl_runtime_rs::String,
    pub success: bool,
}



impl Default for GetRobotMode_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetRobotMode_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetRobotMode_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetRobotMode_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetRobotMode_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetRobotMode_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetRobotMode_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetRobotMode_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetRobotMode_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetRobotMode_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetSafetyMode_Request__init(msg: *mut GetSafetyMode_Request) -> bool;
    fn ur_dashboard_msgs__srv__GetSafetyMode_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetSafetyMode_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetSafetyMode_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetSafetyMode_Request>);
    fn ur_dashboard_msgs__srv__GetSafetyMode_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetSafetyMode_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<GetSafetyMode_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetSafetyMode_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetSafetyMode_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for GetSafetyMode_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetSafetyMode_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetSafetyMode_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetSafetyMode_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetSafetyMode_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetSafetyMode_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetSafetyMode_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetSafetyMode_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetSafetyMode_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetSafetyMode_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__GetSafetyMode_Response__init(msg: *mut GetSafetyMode_Response) -> bool;
    fn ur_dashboard_msgs__srv__GetSafetyMode_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<GetSafetyMode_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__GetSafetyMode_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<GetSafetyMode_Response>);
    fn ur_dashboard_msgs__srv__GetSafetyMode_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<GetSafetyMode_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<GetSafetyMode_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__GetSafetyMode_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct GetSafetyMode_Response {
    pub safety_mode: crate::msg::rmw::SafetyMode,
    pub answer: rosidl_runtime_rs::String,
    pub success: bool,
}



impl Default for GetSafetyMode_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__GetSafetyMode_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__GetSafetyMode_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for GetSafetyMode_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetSafetyMode_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetSafetyMode_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__GetSafetyMode_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for GetSafetyMode_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for GetSafetyMode_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/GetSafetyMode_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__IsProgramRunning_Request__init(msg: *mut IsProgramRunning_Request) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramRunning_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<IsProgramRunning_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramRunning_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<IsProgramRunning_Request>);
    fn ur_dashboard_msgs__srv__IsProgramRunning_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<IsProgramRunning_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<IsProgramRunning_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__IsProgramRunning_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramRunning_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for IsProgramRunning_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__IsProgramRunning_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__IsProgramRunning_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for IsProgramRunning_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramRunning_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramRunning_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramRunning_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for IsProgramRunning_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for IsProgramRunning_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/IsProgramRunning_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__IsProgramRunning_Response__init(msg: *mut IsProgramRunning_Response) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramRunning_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<IsProgramRunning_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramRunning_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<IsProgramRunning_Response>);
    fn ur_dashboard_msgs__srv__IsProgramRunning_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<IsProgramRunning_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<IsProgramRunning_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__IsProgramRunning_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramRunning_Response {
    pub answer: rosidl_runtime_rs::String,
    pub program_running: bool,
    pub success: bool,
}



impl Default for IsProgramRunning_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__IsProgramRunning_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__IsProgramRunning_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for IsProgramRunning_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramRunning_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramRunning_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramRunning_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for IsProgramRunning_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for IsProgramRunning_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/IsProgramRunning_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__IsProgramSaved_Request__init(msg: *mut IsProgramSaved_Request) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramSaved_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<IsProgramSaved_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramSaved_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<IsProgramSaved_Request>);
    fn ur_dashboard_msgs__srv__IsProgramSaved_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<IsProgramSaved_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<IsProgramSaved_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__IsProgramSaved_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramSaved_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for IsProgramSaved_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__IsProgramSaved_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__IsProgramSaved_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for IsProgramSaved_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramSaved_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramSaved_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramSaved_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for IsProgramSaved_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for IsProgramSaved_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/IsProgramSaved_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__IsProgramSaved_Response__init(msg: *mut IsProgramSaved_Response) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramSaved_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<IsProgramSaved_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__IsProgramSaved_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<IsProgramSaved_Response>);
    fn ur_dashboard_msgs__srv__IsProgramSaved_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<IsProgramSaved_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<IsProgramSaved_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__IsProgramSaved_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsProgramSaved_Response {
    pub answer: rosidl_runtime_rs::String,
    pub program_name: rosidl_runtime_rs::String,
    pub program_saved: bool,
    pub success: bool,
}



impl Default for IsProgramSaved_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__IsProgramSaved_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__IsProgramSaved_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for IsProgramSaved_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramSaved_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramSaved_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsProgramSaved_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for IsProgramSaved_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for IsProgramSaved_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/IsProgramSaved_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Load_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__Load_Request__init(msg: *mut Load_Request) -> bool;
    fn ur_dashboard_msgs__srv__Load_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Load_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__Load_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Load_Request>);
    fn ur_dashboard_msgs__srv__Load_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Load_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<Load_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__Load_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Load_Request {
    pub filename: rosidl_runtime_rs::String,
}



impl Default for Load_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__Load_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__Load_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Load_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Load_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Load_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Load_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Load_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Load_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/Load_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Load_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Load_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__Load_Response__init(msg: *mut Load_Response) -> bool;
    fn ur_dashboard_msgs__srv__Load_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Load_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__Load_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Load_Response>);
    fn ur_dashboard_msgs__srv__Load_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Load_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<Load_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__Load_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Load_Response {
    pub answer: rosidl_runtime_rs::String,
    pub success: bool,
}



impl Default for Load_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__Load_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__Load_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Load_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Load_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Load_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Load_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Load_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Load_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/Load_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Load_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Popup_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__Popup_Request__init(msg: *mut Popup_Request) -> bool;
    fn ur_dashboard_msgs__srv__Popup_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Popup_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__Popup_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Popup_Request>);
    fn ur_dashboard_msgs__srv__Popup_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Popup_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<Popup_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__Popup_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Popup_Request {
    pub message: rosidl_runtime_rs::String,
}



impl Default for Popup_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__Popup_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__Popup_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Popup_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Popup_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Popup_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Popup_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Popup_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Popup_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/Popup_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Popup_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Popup_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__Popup_Response__init(msg: *mut Popup_Response) -> bool;
    fn ur_dashboard_msgs__srv__Popup_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<Popup_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__Popup_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<Popup_Response>);
    fn ur_dashboard_msgs__srv__Popup_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<Popup_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<Popup_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__Popup_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct Popup_Response {
    pub answer: rosidl_runtime_rs::String,
    pub success: bool,
}



impl Default for Popup_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__Popup_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__Popup_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for Popup_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Popup_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Popup_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__Popup_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for Popup_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for Popup_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/Popup_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__Popup_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__RawRequest_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__RawRequest_Request__init(msg: *mut RawRequest_Request) -> bool;
    fn ur_dashboard_msgs__srv__RawRequest_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RawRequest_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__RawRequest_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RawRequest_Request>);
    fn ur_dashboard_msgs__srv__RawRequest_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RawRequest_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<RawRequest_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__RawRequest_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RawRequest_Request {
    pub query: rosidl_runtime_rs::String,
}



impl Default for RawRequest_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__RawRequest_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__RawRequest_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RawRequest_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__RawRequest_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__RawRequest_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__RawRequest_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RawRequest_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RawRequest_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/RawRequest_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__RawRequest_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__RawRequest_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__RawRequest_Response__init(msg: *mut RawRequest_Response) -> bool;
    fn ur_dashboard_msgs__srv__RawRequest_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RawRequest_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__RawRequest_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RawRequest_Response>);
    fn ur_dashboard_msgs__srv__RawRequest_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RawRequest_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<RawRequest_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__RawRequest_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RawRequest_Response {
    pub answer: rosidl_runtime_rs::String,
}



impl Default for RawRequest_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__RawRequest_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__RawRequest_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RawRequest_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__RawRequest_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__RawRequest_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__RawRequest_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RawRequest_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RawRequest_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/RawRequest_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__RawRequest_Response() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl_Request() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Request__init(msg: *mut IsInRemoteControl_Request) -> bool;
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Request__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<IsInRemoteControl_Request>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Request__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<IsInRemoteControl_Request>);
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Request__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<IsInRemoteControl_Request>, out_seq: *mut rosidl_runtime_rs::Sequence<IsInRemoteControl_Request>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__IsInRemoteControl_Request
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsInRemoteControl_Request {
    pub structure_needs_at_least_one_member: u8,
}



impl Default for IsInRemoteControl_Request {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__IsInRemoteControl_Request__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__IsInRemoteControl_Request__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for IsInRemoteControl_Request {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsInRemoteControl_Request__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsInRemoteControl_Request__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsInRemoteControl_Request__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for IsInRemoteControl_Request {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for IsInRemoteControl_Request where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/IsInRemoteControl_Request";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl_Request() }
  }
}


#[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl_Response() -> *const std::os::raw::c_void;
}

#[link(name = "ur_dashboard_msgs__rosidl_generator_c")]
extern "C" {
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Response__init(msg: *mut IsInRemoteControl_Response) -> bool;
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Response__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<IsInRemoteControl_Response>, size: usize) -> bool;
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Response__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<IsInRemoteControl_Response>);
    fn ur_dashboard_msgs__srv__IsInRemoteControl_Response__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<IsInRemoteControl_Response>, out_seq: *mut rosidl_runtime_rs::Sequence<IsInRemoteControl_Response>) -> bool;
}

// Corresponds to ur_dashboard_msgs__srv__IsInRemoteControl_Response
#[repr(C)]
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct IsInRemoteControl_Response {
    pub answer: rosidl_runtime_rs::String,
    pub remote_control: bool,
    pub success: bool,
}



impl Default for IsInRemoteControl_Response {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !ur_dashboard_msgs__srv__IsInRemoteControl_Response__init(&mut msg as *mut _) {
        panic!("Call to ur_dashboard_msgs__srv__IsInRemoteControl_Response__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for IsInRemoteControl_Response {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsInRemoteControl_Response__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsInRemoteControl_Response__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { ur_dashboard_msgs__srv__IsInRemoteControl_Response__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for IsInRemoteControl_Response {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for IsInRemoteControl_Response where Self: Sized {
  const TYPE_NAME: &'static str = "ur_dashboard_msgs/srv/IsInRemoteControl_Response";
  fn get_type_support() -> *const std::os::raw::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl_Response() }
  }
}






  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__AddToLog() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__AddToLog
  pub struct AddToLog;

  impl rosidl_runtime_rs::Service for AddToLog {
    type Request = crate::srv::rmw::AddToLog_Request;
    type Response = crate::srv::rmw::AddToLog_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__AddToLog() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__GetLoadedProgram
  pub struct GetLoadedProgram;

  impl rosidl_runtime_rs::Service for GetLoadedProgram {
    type Request = crate::srv::rmw::GetLoadedProgram_Request;
    type Response = crate::srv::rmw::GetLoadedProgram_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetLoadedProgram() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetProgramState() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__GetProgramState
  pub struct GetProgramState;

  impl rosidl_runtime_rs::Service for GetProgramState {
    type Request = crate::srv::rmw::GetProgramState_Request;
    type Response = crate::srv::rmw::GetProgramState_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetProgramState() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__GetRobotMode
  pub struct GetRobotMode;

  impl rosidl_runtime_rs::Service for GetRobotMode {
    type Request = crate::srv::rmw::GetRobotMode_Request;
    type Response = crate::srv::rmw::GetRobotMode_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetRobotMode() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__GetSafetyMode
  pub struct GetSafetyMode;

  impl rosidl_runtime_rs::Service for GetSafetyMode {
    type Request = crate::srv::rmw::GetSafetyMode_Request;
    type Response = crate::srv::rmw::GetSafetyMode_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__GetSafetyMode() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__IsProgramRunning
  pub struct IsProgramRunning;

  impl rosidl_runtime_rs::Service for IsProgramRunning {
    type Request = crate::srv::rmw::IsProgramRunning_Request;
    type Response = crate::srv::rmw::IsProgramRunning_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramRunning() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__IsProgramSaved
  pub struct IsProgramSaved;

  impl rosidl_runtime_rs::Service for IsProgramSaved {
    type Request = crate::srv::rmw::IsProgramSaved_Request;
    type Response = crate::srv::rmw::IsProgramSaved_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsProgramSaved() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Load() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__Load
  pub struct Load;

  impl rosidl_runtime_rs::Service for Load {
    type Request = crate::srv::rmw::Load_Request;
    type Response = crate::srv::rmw::Load_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Load() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Popup() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__Popup
  pub struct Popup;

  impl rosidl_runtime_rs::Service for Popup {
    type Request = crate::srv::rmw::Popup_Request;
    type Response = crate::srv::rmw::Popup_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__Popup() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__RawRequest() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__RawRequest
  pub struct RawRequest;

  impl rosidl_runtime_rs::Service for RawRequest {
    type Request = crate::srv::rmw::RawRequest_Request;
    type Response = crate::srv::rmw::RawRequest_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__RawRequest() }
    }
  }




  #[link(name = "ur_dashboard_msgs__rosidl_typesupport_c")]
  extern "C" {
      fn rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl() -> *const std::os::raw::c_void;
  }

  // Corresponds to ur_dashboard_msgs__srv__IsInRemoteControl
  pub struct IsInRemoteControl;

  impl rosidl_runtime_rs::Service for IsInRemoteControl {
    type Request = crate::srv::rmw::IsInRemoteControl_Request;
    type Response = crate::srv::rmw::IsInRemoteControl_Response;

    fn get_type_support() -> *const std::os::raw::c_void {
      // SAFETY: No preconditions for this function.
      unsafe { rosidl_typesupport_c__get_service_type_support_handle__ur_dashboard_msgs__srv__IsInRemoteControl() }
    }
  }



}  // mod rmw
